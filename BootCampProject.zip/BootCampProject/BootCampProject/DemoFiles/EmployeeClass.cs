﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    public class EmployeeClass
    {
        public string name { get; set; }
        public string designation { get; set; }
        public string location { get; set; }

        public EmployeeClass()
        {
            name="";
            designation="";
            location="";
        }
       

    }
}
