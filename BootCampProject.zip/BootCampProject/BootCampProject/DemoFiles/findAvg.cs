﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class findAvg
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter 5 numbers ");
            int[] data = new int[5];
            for(int i = 0; i < 5; i++)
            {
                Console.WriteLine("Enter number: ");
                data[i] = int.Parse(Console.ReadLine());
            }

            //sum 
            int sum = 0;
            for(int i = 0; i < data.Length; i++)
            {
                sum += data[i];
            }

            double average = sum / data.Length;
            Console.WriteLine(average);
            Console.ReadLine();
        }
    }
}
