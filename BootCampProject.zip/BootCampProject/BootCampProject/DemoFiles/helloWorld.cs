﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class helloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hello world");
            Console.ReadLine();
        }
    }
}
