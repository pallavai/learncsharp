﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class calculateSIAmount
    {
        static void Main(string[] args)
        {
            int principal = 0;
            double rate = 0.0;
            int time = 0;
            double simpInterest = 0.0;
            double amount = 0.0;

            Console.WriteLine("Enter Principal: ");
            principal = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Rate: ");
            rate = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Time: ");
            time = int.Parse(Console.ReadLine());

            simpInterest = (principal * rate * time) / 100;
            Console.WriteLine(simpInterest);
            amount = principal + simpInterest;
            Console.WriteLine(amount);
            Console.ReadLine();
        }
    }
}
