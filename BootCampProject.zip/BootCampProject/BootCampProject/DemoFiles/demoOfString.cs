﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class demoOfString
    {
        static void Main(string[] args)
        {
            string mainString = "My name is James Bond";
            Console.WriteLine("Enter substring: ");
            string substr = Console.ReadLine();
            substr.Trim();
            if (mainString.IndexOf(substr) >= 0)
            {
                Console.WriteLine("Found");
            }
            else
            {
                Console.WriteLine("Better luck next time");
            }
            Console.Read();

            
        }
    }
}
