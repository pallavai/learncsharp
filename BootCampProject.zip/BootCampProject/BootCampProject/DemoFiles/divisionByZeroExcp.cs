﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class divisionByZeroExcp
    {
        static void Main(string[] args)
        {
            int numerator = 0;
            int denominator = 0;
            double quotient = 0.0;
            Console.WriteLine("Enter numerator and denominator: ");
            numerator = int.Parse(Console.ReadLine());
            denominator = int.Parse(Console.ReadLine());
            try
            {
                quotient = numerator / denominator;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.StackTrace);

            }
            finally
            {
                Console.WriteLine("This is a division program");
            }
            Console.WriteLine(quotient);
            Console.Read();
        }
    }
}
