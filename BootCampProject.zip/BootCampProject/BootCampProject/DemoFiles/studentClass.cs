﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class studentClass
    {
        int rollnum { get; set; }
        string sname { get; set; }
        int grade { get; set; }
        double percentage { get; set; }

        studentClass()
        {
            rollnum = 0;
            sname = "";
            grade = 0;
            percentage = 0.0;
        }

       

        void printDetails()
        {
            Console.Write("Rollnum: " + rollnum + " Name: " + sname + " Grade: " + grade + " Percentage: " + percentage);
        }

        static void Main(string[] args)
        {
            studentClass student = new studentClass();
            student.rollnum = 1;
            student.sname = "Bernie";
            student.grade = 5;
            student.percentage = 100.00;
            student.printDetails();
            Console.Read();
            
        }
    }
}
