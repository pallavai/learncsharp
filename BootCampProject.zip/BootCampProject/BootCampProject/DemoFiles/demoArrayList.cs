﻿using System;
using System.Collections;
using System.Runtime.Remoting.Services;

namespace BootCampProject.DemoFiles
{
    class demoArrayList
    {
        static void Main(string[] args)
        {
            ArrayList demoList = new ArrayList();
            Console.WriteLine("Enter 5 numbers: ");
            for(int i = 0; i < 5; i++)
            {
                demoList.Add(int.Parse(Console.ReadLine()));

            }
            demoList.Add(76);
            demoList.RemoveAt(3);
            demoList.Sort();
            foreach(int num in demoList)
            {
                Console.WriteLine(num);
            }

            Console.ReadLine();
        }
    }
}
