﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class circleArea
    {
        static void Main(string[] args)
        {
            double radius = 0.0;
            double area = 0.0;
            Console.WriteLine("Enter Radius: ");
            radius = double.Parse(Console.ReadLine()); //converting the string provided by the end user to the double value
            area = 3.141 * radius * radius;
            Console.WriteLine("Area of circle is: " + area);
            Console.ReadLine();
        }


    }
}
