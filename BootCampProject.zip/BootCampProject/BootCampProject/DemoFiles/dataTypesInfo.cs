﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class dataTypesInfo
    {
        static void Main(string[] args)
        {
            int numInt = 0;
            double numDoub = 0.0;
            string str = "hello";
            Boolean flag = false;


        }
    }
}
