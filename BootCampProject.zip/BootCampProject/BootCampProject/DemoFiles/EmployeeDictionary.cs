﻿
using System;
using System.Collections.Generic;



namespace BootCampProject.DemoFiles
{
    class EmployeeDictionary
    {
        static void Main(string[] args)
        {
            Dictionary<int, EmployeeClass> empDict = new Dictionary<int, EmployeeClass>();
            EmployeeClass[] emps=new EmployeeClass[3];
            for(int e = 0; e < emps.Length; e++)
            {
                emps[e] = new EmployeeClass();
            }
           
           
            emps[0].name = "Jacinda";
            emps[0].designation = "PM";
            emps[0].location="NZ";

            empDict.Add(1, emps[0]);

            emps[1].name = "Trump";
            emps[1].designation = "President";
            emps[1].location = "USA";

            empDict.Add(2, emps[1]);

            emps[2].name = "Trudeau";
            emps[2].designation = "PM";
            emps[2].location = "Canada";

            empDict.Add(3, emps[2]);

            foreach (KeyValuePair<int, EmployeeClass> data in empDict)
            {
                Console.WriteLine("{0}", data.Key);
                Console.WriteLine(data.Value.name);
                Console.WriteLine(data.Value.designation);
                Console.WriteLine(data.Value.location);


            }
            Console.Read();


        }
    }
}
