﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class demoWhile
    {
        static void Main(string[] args)
        {
            int i =1;
            while (i < 100)
            {
                if (i % 7 == 0)
                {
                    Console.WriteLine(i);
                }
                i = i + 1;
            }
            Console.ReadLine();
        }
    }
}
