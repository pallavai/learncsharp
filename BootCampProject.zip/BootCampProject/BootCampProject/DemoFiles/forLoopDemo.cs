﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootCampProject.DemoFiles
{
    class forLoopDemo
    {
        static void Main(string[] args)
        {
            for(int i = 0; i < 100; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine(i);
                }
            }
            Console.WriteLine("--------------------------------------\n");

            for(int j = 100; j >= 0; j--)
            {
                if (j % 2 != 0)
                {
                    Console.WriteLine(j);
                }
            }

            Console.ReadLine();
        }
    }
}
